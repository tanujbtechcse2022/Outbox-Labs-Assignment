
import { useState } from "react";

export default function Home() {
  const [emails, setEmails] = useState("");

  const schedule = async () => {
    await fetch("http://localhost:4000/api/schedule", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        emails: emails.split(","),
        subject: "Test Email",
        body: "Hello from ReachInbox",
        startTime: Date.now()
      })
    });
    alert("Scheduled!");
  };

  return (
    <div style={{ padding: 40 }}>
      <h1>Email Scheduler</h1>
      <textarea onChange={e => setEmails(e.target.value)} />
      <br />
      <button onClick={schedule}>Schedule Emails</button>
    </div>
  );
}
