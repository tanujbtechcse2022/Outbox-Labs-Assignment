
import { Queue } from "bullmq";
import IORedis from "ioredis";

export const redis = new IORedis(process.env.REDIS_URL!);

export const emailQueue = new Queue("email-queue", {
  connection: redis
});
