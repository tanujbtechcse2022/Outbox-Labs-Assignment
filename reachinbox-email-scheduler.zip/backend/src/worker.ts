
import { Worker } from "bullmq";
import nodemailer from "nodemailer";
import { redis } from "./queue";
import dotenv from "dotenv";

dotenv.config();

const transporter = nodemailer.createTransport({
  host: "smtp.ethereal.email",
  port: 587,
  auth: {
    user: process.env.ETHEREAL_USER,
    pass: process.env.ETHEREAL_PASS
  }
});

new Worker(
  "email-queue",
  async job => {
    const hourKey = `rate:${new Date().toISOString().slice(0,13)}`;
    const count = await redis.incr(hourKey);
    if (count === 1) await redis.expire(hourKey, 3600);

    if (count > Number(process.env.MAX_EMAILS_PER_HOUR)) {
      throw new Error("Rate limit exceeded");
    }

    await transporter.sendMail({
      from: "ReachInbox <test@reachinbox.ai>",
      to: job.data.to,
      subject: job.data.subject,
      text: job.data.body
    });
  },
  {
    connection: redis,
    concurrency: Number(process.env.WORKER_CONCURRENCY)
  }
);
