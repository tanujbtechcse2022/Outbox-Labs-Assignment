
import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { emailQueue } from "./queue";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

app.post("/api/schedule", async (req, res) => {
  const { emails, subject, body, startTime } = req.body;

  let delay = 0;
  for (const email of emails) {
    await emailQueue.add(
      "send-email",
      { to: email, subject, body },
      { delay }
    );
    delay += Number(process.env.DELAY_BETWEEN_EMAILS) * 1000;
  }

  res.json({ message: "Emails scheduled successfully" });
});

app.listen(process.env.PORT || 4000, () =>
  console.log("Backend running")
);
